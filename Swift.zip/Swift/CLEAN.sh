rm parser.out parsetab.py *.class
