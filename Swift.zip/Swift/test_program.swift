print("Hello World!")
print(17)

let language = "swift"

if language == "swift" {
	print("We are working in Swift!")
}

var a = 9
print(a)

if a > 7 {
	print("a is greater than 7")
}
else {
	print("a is less than or equal to 7")
}

if a == 9 {
	print("a is 9")
}

